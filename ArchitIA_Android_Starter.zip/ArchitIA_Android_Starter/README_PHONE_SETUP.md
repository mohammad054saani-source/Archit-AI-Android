# Archit IA — Android starter (phone-first)

This is the first Kotlin/Gradle starter for Archit IA. It implements:
- A floor-plan image picker using Android's document picker
- A selected-image preview
- Project naming and local saving on the phone
- A basic saved-project gallery and reopen action
- A clearly marked placeholder for 3D generation (no 3D backend is connected yet)

## Build route: GitHub Actions (cloud)

1. On your Android phone, open https://github.com and sign in or create an account.
2. Create a new repository named `ArchitIA-Android`. A private repository is fine.
3. Upload the contents of this ZIP into the repository's main branch. Upload the files and folders, not the ZIP as a single file.
4. Open the repository's **Actions** tab.
5. Select **Build Archit IA APK** and tap **Run workflow** (or push to `main` to trigger it).
6. Wait for the workflow to finish. If it succeeds, open the run and download the `ArchitIA-debug-apk` artifact.
7. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installation from your browser or file manager.

## Important
- This starter has not yet been built or tested on a cloud runner. The first GitHub Actions run is the build verification.
- A debug APK is for testing. A release APK should later be signed securely before distribution.
- The Generate 3D button is intentionally a placeholder until a real 2D-to-3D service is selected and connected.
- Keep this repository private if you do not want the source code to be public.

## Project structure
- `app/src/main/java/com/architia/app/MainActivity.kt` — first upload/gallery screen
- `app/src/main/AndroidManifest.xml` — Android app manifest
- `app/build.gradle.kts` — app build configuration
- `.github/workflows/android.yml` — cloud APK build workflow
