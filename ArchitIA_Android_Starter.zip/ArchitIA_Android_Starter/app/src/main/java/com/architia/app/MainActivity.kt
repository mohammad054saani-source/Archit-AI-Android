package com.architia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("architia_projects", MODE_PRIVATE) }
    private var selectedUri: Uri? = null
    private lateinit var preview: ImageView
    private lateinit var projectName: EditText
    private lateinit var gallery: LinearLayout
    private lateinit var generateButton: Button
    private val ink = Color.rgb(31, 41, 55)
    private val muted = Color.rgb(100, 116, 139)
    private val paper = Color.rgb(248, 250, 252)
    private val accent = Color.rgb(37, 99, 235)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, bold: Boolean = false, color: Int = ink): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(2), dp(5), dp(2), dp(5))
        }
    }

    private fun button(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }
    }

    private fun showHome() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
            setBackgroundColor(paper)
        }
        scroll.addView(page)
        page.addView(text("ARCHIT IA", 13f, true, accent))
        page.addView(text("Turn your floor plan into a design project.", 25f, true))
        page.addView(text("Start by choosing a clear photo or image of your floor plan.", 14f, false, muted))

        val uploadPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(Color.WHITE)
        }
        val panelParams = LinearLayout.LayoutParams(-1, dp(280))
        panelParams.topMargin = dp(18)
        page.addView(uploadPanel, panelParams)

        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(241, 245, 249))
            contentDescription = "Selected floor plan preview"
        }
        uploadPanel.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        uploadPanel.addView(text("Your floor plan preview will appear here", 13f, false, muted))
        uploadPanel.addView(button("Choose floor plan", ::pickPlan))

        page.addView(text("Project name", 14f, true))
        projectName = EditText(this).apply {
            hint = "e.g. My 3-bedroom house"
            singleLine = true
            setTextColor(ink)
        }
        page.addView(projectName, LinearLayout.LayoutParams(-1, dp(54)))
        page.addView(text("For best results: keep the whole plan in frame, take the photo from directly above, and use good lighting.", 13f, false, muted))
        generateButton = button("Generate 3D", ::generate3D).apply { isEnabled = false }
        page.addView(generateButton)
        page.addView(text("3D generation will be enabled when a real generation service is connected.", 12f, false, muted))

        page.addView(text("My projects", 21f, true).apply {
            setPadding(0, dp(28), 0, dp(8))
        })
        gallery = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(gallery)
        page.addView(button("Refresh projects", ::refreshGallery))
        setContentView(scroll)
        refreshGallery()
    }

    private fun pickPlan() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, 1001)
    }

    @Deprecated("Legacy callback retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            selectedUri = uri
            preview.setImageURI(uri)
            generateButton.isEnabled = true
            Toast.makeText(this, "Floor plan selected", Toast.LENGTH_SHORT).show()
            saveProject()
        }
    }

    private fun saveProject() {
        val uri = selectedUri ?: return
        val name = projectName.text.toString().trim().ifEmpty { "Untitled project" }
        val items = readProjects()
        val item = JSONObject().put("name", name).put("uri", uri.toString())
        items.put(item)
        prefs.edit().putString("items", items.toString()).apply()
        refreshGallery()
        Toast.makeText(this, "Project saved to this phone", Toast.LENGTH_SHORT).show()
    }

    private fun readProjects(): JSONArray {
        return try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
    }

    private fun refreshGallery() {
        if (!::gallery.isInitialized) return
        gallery.removeAllViews()
        val items = readProjects()
        if (items.length() == 0) {
            gallery.addView(text("No saved projects yet. Choose a floor plan to create your first project.", 14f, false, muted))
            return
        }
        for (i in items.length() - 1 downTo 0) {
            val item = items.optJSONObject(i) ?: continue
            val name = item.optString("name", "Untitled project")
            val uriText = item.optString("uri", "")
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setBackgroundColor(Color.WHITE)
            }
            row.addView(text(name, 16f, true))
            row.addView(text("Saved on this device", 12f, false, muted))
            row.addView(button("Open project") {
                try {
                    val uri = Uri.parse(uriText)
                    selectedUri = uri
                    projectName.setText(name)
                    preview.setImageURI(uri)
                    generateButton.isEnabled = true
                    Toast.makeText(this, "Project opened", Toast.LENGTH_SHORT).show()
                } catch (_: Exception) {
                    Toast.makeText(this, "Could not open this image. Please choose it again.", Toast.LENGTH_LONG).show()
                }
            })
            val params = LinearLayout.LayoutParams(-1, -2)
            params.bottomMargin = dp(10)
            gallery.addView(row, params)
        }
    }

    private fun generate3D() {
        Toast.makeText(this, "The 3D generation service is not connected yet. Your plan can be saved for now.", Toast.LENGTH_LONG).show()
    }
}
